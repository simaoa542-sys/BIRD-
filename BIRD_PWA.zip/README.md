# BIRD — Gestão de Criadouro

Ficheiros prontos para publicação como PWA.

## Publicar
Coloca todos os ficheiros na raiz de um alojamento HTTPS, por exemplo GitHub Pages.

## Instalar no iPhone
Abre o endereço no Safari → Partilhar → Adicionar ao ecrã principal → ativa "Abrir como aplicação Web" → Adicionar.

## Dados
Os registos são guardados localmente no dispositivo através de localStorage. Esta versão não usa login nem servidor de base de dados.
