const KEY="bird_v2";
let db=JSON.parse(localStorage.getItem(KEY)||'{"aves":[],"casais":[],"sexagens":[],"medicacoes":[],"cedencias":[],"eventos":[]}');
const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
const fmt=d=>d?new Date(d+"T00:00:00").toLocaleDateString("pt-PT"):"—";
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2);
function persist(){localStorage.setItem(KEY,JSON.stringify(db));render();toast("Guardado com sucesso");}
function go(page){$$(".page").forEach(p=>p.classList.toggle("active",p.id===page));$$("nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===page));$("#nav").classList.remove("open");scrollTo({top:0,behavior:"smooth"})}
$$("[data-page]").forEach(b=>b.onclick=()=>go(b.dataset.page));
$("#menuBtn").onclick=()=>$("#nav").classList.toggle("open");

const forms={
ave:{title:"Nova ave",arr:"aves",fields:[["anilha","Número de anilha","text",1],["nome","Nome","text"],["especie","Espécie","text"],["sexo","Sexo","select",0,["Macho","Fêmea","Desconhecido"]],["notas","Notas","textarea"]]},
casal:{title:"Novo casal",arr:"casais",fields:[["macho","Anilha do macho","text",1],["femea","Anilha da fêmea","text",1],["nome","Nome do casal","text"],["notas","Notas","textarea"]]},
sexagem:{title:"Nova sexagem",arr:"sexagens",fields:[["anilha","Número de anilha","text",1],["resultado","Resultado","select",1,["Macho","Fêmea","Indeterminado"]],["data","Data","date"],["notas","Notas","textarea"]]},
medicacao:{title:"Registar medicação",arr:"medicacoes",fields:[["anilha","Número de anilha","text",1],["medicamento","Medicamento","text",1],["inicio","Data de início","date",1],["fim","Data de fim","date"],["notas","Notas","textarea"]]},
cedencia:{title:"Registar cedência",arr:"cedencias",fields:[["anilha","Número de anilha","text",1],["destinatario","Cedida a","text",1],["data","Data","date",1],["notas","Notas","textarea"]]},
evento:{title:"Novo acontecimento",arr:"eventos",fields:[["data","Data","date",1],["titulo","Título","text",1],["tipo","Tipo","select",0,["Geral","Criação","Medicação","Sexagem","Cedência","Outro"]],["notas","Notas","textarea"]]}
};
function openModal(type){
 const c=forms[type],f=$("#form"); $("#modalTitle").textContent=c.title; f.dataset.type=type;
 f.innerHTML=c.fields.map(x=>`<div class="field"><label>${x[1]}</label>${x[2]=="select"?`<select name="${x[0]}" ${x[3]?"required":""}><option value="">Selecionar...</option>${x[4].map(v=>`<option>${v}</option>`).join("")}</select>`:x[2]=="textarea"?`<textarea name="${x[0]}"></textarea>`:`<input name="${x[0]}" type="${x[2]}" ${x[3]?"required":""}`}></div>`).join("")+'<button class="submit">Guardar</button>';
 $("#modal").classList.add("open");
}
$$("[data-modal]").forEach(b=>b.onclick=()=>openModal(b.dataset.modal));
$("#close").onclick=()=>$("#modal").classList.remove("open");
$("#modal").onclick=e=>{if(e.target.id==="modal")$("#modal").classList.remove("open")};
$("#form").onsubmit=e=>{e.preventDefault();let t=e.currentTarget.dataset.type,c=forms[t],d=Object.fromEntries(new FormData(e.currentTarget));d.id=uid();db[c.arr].push(d);persist();$("#modal").classList.remove("open")};
function del(arr,id){if(confirm("Eliminar este registo?")){db[arr]=db[arr].filter(x=>x.id!==id);persist()}}
function item(title,lines,arr,id){return `<article class="item"><h3>${esc(title)}</h3>${lines.filter(Boolean).map(x=>`<p>${x}</p>`).join("")}<button class="delete" onclick="del('${arr}','${id}')">Eliminar</button></article>`}
function render(){
 $("#nAves").textContent=db.aves.length;$("#nCasais").textContent=db.casais.length;$("#nSexagens").textContent=db.sexagens.length;$("#nCedencias").textContent=db.cedencias.length;
 $("#avesList").innerHTML=db.aves.length?db.aves.map(x=>item(x.nome||x.anilha,[`Anilha: <b>${esc(x.anilha)}</b>`,x.especie&&`Espécie: ${esc(x.especie)}`,x.sexo&&`Sexo: ${esc(x.sexo)}`],"aves",x.id)).join(""):'<div class="empty">Ainda não tens aves registadas.</div>';
 $("#casaisList").innerHTML=db.casais.length?db.casais.map(x=>item(x.nome||"Casal",[`Macho: <b>${esc(x.macho)}</b>`,`Fêmea: <b>${esc(x.femea)}</b>`,x.notas&&esc(x.notas)],"casais",x.id)).join(""):'<div class="empty">Ainda não tens casais registados.</div>';
 $("#sexagensList").innerHTML=db.sexagens.length?db.sexagens.map(x=>item(x.anilha,[`Resultado: <b>${esc(x.resultado)}</b>`,x.data&&`Data: ${fmt(x.data)}`,x.notas&&esc(x.notas)],"sexagens",x.id)).join(""):'<div class="empty">Ainda não tens sexagens registadas.</div>';
 $("#medicacoesList").innerHTML=db.medicacoes.length?db.medicacoes.map(x=>item(x.medicamento,[`Anilha: <b>${esc(x.anilha)}</b>`,`Início: ${fmt(x.inicio)}`,`Fim: ${fmt(x.fim)}`,x.notas&&esc(x.notas)],"medicacoes",x.id)).join(""):'<div class="empty">Ainda não tens medicação registada.</div>';
 $("#cedenciasList").innerHTML=db.cedencias.length?db.cedencias.map(x=>item(x.anilha,[`Cedida a: <b>${esc(x.destinatario)}</b>`,`Data: ${fmt(x.data)}`,x.notas&&esc(x.notas)],"cedencias",x.id)).join(""):'<div class="empty">Ainda não tens cedências registadas.</div>';
 const ev=[...db.eventos].sort((a,b)=>a.data.localeCompare(b.data));$("#events").innerHTML=ev.slice(0,5).map(x=>`<div class="event"><b>${esc(x.titulo)}</b><br><small>${fmt(x.data)} · ${esc(x.tipo||"Geral")}</small></div>`).join("")||'<p style="color:#647187">Nenhum acontecimento registado.</p>';
 calendar();
}
function calendar(){
 const c=$("#calendar"),n=new Date(),y=n.getFullYear(),m=n.getMonth(),days=new Date(y,m+1,0).getDate(),off=(new Date(y,m,1).getDay()+6)%7;
 let h=`<div style="grid-column:1/-1;padding:5px"><b>${n.toLocaleDateString("pt-PT",{month:"long",year:"numeric"})}</b></div>`;
 for(let i=0;i<off;i++)h+="<div></div>";
 for(let d=1;d<=days;d++){let ds=`${y}-${String(m+1).padStart(2,"0")}-${String(d).padStart(2,"0")}`,ev=db.eventos.filter(x=>x.data===ds);h+=`<div class="day ${d===n.getDate()?"today":""}"><b>${d}</b>${ev.map(x=>`<span class="dot">${esc(x.titulo)}</span>`).join("")}</div>`}
 c.innerHTML=h;
}
$("#search").oninput=()=>{
 const q=$("#search").value.trim().toLowerCase(),r=$("#result");
 if(!q){r.textContent="Introduz uma anilha para pesquisar.";return}
 const a=db.aves.find(x=>x.anilha?.toLowerCase()===q),s=db.sexagens.find(x=>x.anilha?.toLowerCase()===q),c=db.cedencias.find(x=>x.anilha?.toLowerCase()===q),m=db.medicacoes.filter(x=>x.anilha?.toLowerCase()===q);
 if(!a&&!s&&!c&&!m){r.textContent="Não foi encontrada nenhuma informação para esta anilha.";return}
 r.innerHTML=`<b>${esc(a?.nome||"Ave encontrada")}</b>${a?.especie?" · "+esc(a.especie):""}<br>🧬 Sexagem: ${s?`<b>${esc(s.resultado)}</b>`:"não registada"}${c?`<br>📋 Cedência: ${fmt(c.data)} — ${esc(c.destinatario)}`:""}${m.length?`<br>💊 Medicação: ${m.map(x=>esc(x.medicamento)).join(", ")}`:""}`;
};
function toast(t){let x=$("#toast");x.textContent=t;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),1800)}
render();
if("serviceWorker"in navigator)navigator.serviceWorker.register("sw.js").catch(()=>{});
